// Select color, table, size input (variables), this is for user:
let color = document.getElementById('colorPicker');
let table = document.getElementById('pixelcanvas');
let sizePicker = document.getElementById('sizepicker');
//this is for my submit button:
colorPicker.addEventListener;
sizePicker.addEventListener;
// When size is submitted by the user, call makeGrid()

function makeGrid() {

// for function with let variable to define the table and grid using methods from the
document. DOM object

}

// 1 Your users should be able to:
Dynamically set the size of the table as an _N_ by _M_ grid.
Click a cell in the grid to fill that cell with the chosen color.

//2 Defining variables with const and let
Accessing the DOM using methods of the document object
Declaring functions and attaching them to DOM objects as event listeners
Writing nested loops and using loop variables

//3 define variables by selecting the DOM elements that the user will interact with;this
is where the javascript variables will come into play ie the submit button
the table  and the color picker need to be accessed, the value of the color needs
to be stored

//4 add event listeners to the relevant DOM elements so that user input can be color
values and table sizes can be dynamically set by the user.

//5 Set the size of the cross stitch canvas as an _N_ by _M_ grid with the makeGrid()
 function. Use your knowledge of JavaScript loops to dynamically clear and create
 the table based on user input. Each cell should have an event listener that sets
 the background color of the cell to the selected color.Your goal is to build out
  the design.js file to achieve all the interactive elements on the page!

//6 Before submitting, make sure your code follows our style guidelines:
CSS Style Guide
HTML Style Guide
JavaScript Style Guide
Git Style Guide
Create a new repository on GitHub and push your code up to it, making sure to push
 your master branch. Then, connect your GitHub account and select your
Pixel Art Maker project's repository.

//7  You do not need to edit the HTML and CSS files to make your project work.
 You can if you want to.

//quesions:
1. do I need to use jquery to add code - to set it to DOM we can use the
document. object ie document.createElement
2. what is the difference of using
jquery and DOM; this project wants us to use DOM (I think)
3. var is my variable
4. where would I need my nested loop
5. is "let" my method
6. what are my DOM elemEnts anything that interacts with JS and HTML
7. what is console.log, const
